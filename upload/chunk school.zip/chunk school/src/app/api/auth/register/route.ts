import { NextRequest, NextResponse } from 'next/server';
import type { UserRole, Language } from '@/lib/types';

// In-memory store for registered users (demo purposes)
const registeredUsers: Array<{
  id: string;
  email: string;
  name: string;
  role: UserRole;
  language: Language;
  twoFactorEnabled: boolean;
  avatar: string;
}> = [];

let userCounter = 100;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, password, role } = body;

    // Validate required fields
    if (!name || !email || !password || !role) {
      return NextResponse.json(
        { error: 'Name, email, password, and role are required' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      );
    }

    // Validate password length
    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters' },
        { status: 400 }
      );
    }

    // Validate role
    const validRoles: UserRole[] = ['student', 'teacher', 'parent', 'admin', 'owner'];
    if (!validRoles.includes(role)) {
      return NextResponse.json(
        { error: `Invalid role. Must be one of: ${validRoles.join(', ')}` },
        { status: 400 }
      );
    }

    // Check if email already exists in registered users or mock users
    const existingUser = registeredUsers.find((u) => u.email === email);
    if (existingUser) {
      return NextResponse.json(
        { error: 'Email already registered' },
        { status: 409 }
      );
    }

    // Create new user
    userCounter++;
    const newUser = {
      id: `u${userCounter}`,
      email,
      name,
      role,
      language: 'ar' as Language,
      twoFactorEnabled: false,
      avatar: '',
    };

    registeredUsers.push(newUser);

    // Generate a mock JWT token
    const mockToken = `mock_jwt_${newUser.id}_${newUser.role}_${Date.now()}`;

    return NextResponse.json(
      {
        success: true,
        user: newUser,
        token: mockToken,
        message: 'Registration successful',
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
