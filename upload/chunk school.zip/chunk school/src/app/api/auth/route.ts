import { NextRequest, NextResponse } from 'next/server';
import { mockUsers } from '@/lib/mock-data';

const validCredentials: Record<string, string> = {
  'student@champs.dz': 'password123',
  'teacher@champs.dz': 'password123',
  'parent@champs.dz': 'password123',
  'admin@champs.dz': 'password123',
  'owner@champs.dz': 'password123',
};

const emailToRoleKey: Record<string, string> = {
  'student@champs.dz': 'student',
  'teacher@champs.dz': 'teacher',
  'parent@champs.dz': 'parent',
  'admin@champs.dz': 'admin',
  'owner@champs.dz': 'owner',
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    // Check if credentials are valid
    if (validCredentials[email] !== password) {
      return NextResponse.json(
        { error: 'Invalid email or password' },
        { status: 401 }
      );
    }

    // Get the user role key from email
    const roleKey = emailToRoleKey[email];
    if (!roleKey) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const user = mockUsers[roleKey];

    // Generate a mock JWT token
    const mockToken = `mock_jwt_${user.id}_${user.role}_${Date.now()}`;

    return NextResponse.json({
      success: true,
      user,
      token: mockToken,
      message: 'Login successful',
    });
  } catch (error) {
    console.error('Auth error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
