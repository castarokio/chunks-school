import { NextRequest, NextResponse } from 'next/server';
import { mockCourses } from '@/lib/mock-data';
import type { Course } from '@/lib/types';

// In-memory store for any newly created courses
const createdCourses: Course[] = [];
let courseCounter = 100;

export async function GET() {
  try {
    // Combine mock courses with any dynamically created ones
    const allCourses = [...mockCourses, ...createdCourses];
    return NextResponse.json({
      success: true,
      courses: allCourses,
      total: allCourses.length,
    });
  } catch (error) {
    console.error('Courses GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      title,
      titleAr,
      titleFr,
      description,
      descriptionAr,
      descriptionFr,
      category,
      level,
      price,
      currency,
      capacity,
      schedule,
      startDate,
      endDate,
      teacherId,
      teacherName,
    } = body;

    // Check for admin authorization (simplified - in real app, verify JWT)
    const authHeader = request.headers.get('authorization');
    if (!authHeader) {
      return NextResponse.json(
        { error: 'Authorization required' },
        { status: 401 }
      );
    }

    // Validate required fields
    if (!title || !description || !category || !level || !price || !teacherId) {
      return NextResponse.json(
        { error: 'Missing required fields: title, description, category, level, price, teacherId' },
        { status: 400 }
      );
    }

    courseCounter++;
    const newCourse: Course = {
      id: `c${courseCounter}`,
      title,
      titleAr: titleAr || undefined,
      titleFr: titleFr || undefined,
      description,
      descriptionAr: descriptionAr || undefined,
      descriptionFr: descriptionFr || undefined,
      category,
      level,
      price,
      currency: currency || 'DZD',
      capacity: capacity || 25,
      schedule: schedule || '{}',
      startDate: startDate || new Date().toISOString().split('T')[0],
      endDate: endDate || '2026-06-30',
      status: 'active',
      teacherId,
      teacherName: teacherName || undefined,
      enrolledCount: 0,
      rating: 0,
    };

    createdCourses.push(newCourse);

    return NextResponse.json(
      {
        success: true,
        course: newCourse,
        message: 'Course created successfully',
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Courses POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
