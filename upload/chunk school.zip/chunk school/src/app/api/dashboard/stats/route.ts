import { NextRequest, NextResponse } from 'next/server';
import { mockDashboardStats, mockEnrollments, mockCourses } from '@/lib/mock-data';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const role = searchParams.get('role') || 'student';
    const userId = searchParams.get('userId') || 's1';

    // Base stats from mock data
    const baseStats = mockDashboardStats;

    // Return different stats based on role
    let stats: Record<string, unknown>;

    switch (role) {
      case 'student':
        stats = {
          ...baseStats,
          // Student-specific stats
          enrolledCourses: mockEnrollments.filter((e) => e.studentId === userId).length,
          activeCourses: mockEnrollments.filter(
            (e) => e.studentId === userId && e.status === 'approved'
          ).length,
          averageGrade: mockEnrollments
            .filter((e) => e.studentId === userId && e.grade)
            .reduce((sum, e) => sum + (e.grade || 0), 0) /
            Math.max(
              mockEnrollments.filter((e) => e.studentId === userId && e.grade).length,
              1
            ),
          overallProgress: mockEnrollments
            .filter((e) => e.studentId === userId)
            .reduce((sum, e) => sum + e.progress, 0) /
            Math.max(
              mockEnrollments.filter((e) => e.studentId === userId).length,
              1
            ),
        };
        break;

      case 'teacher':
        stats = {
          ...baseStats,
          // Teacher-specific stats
          myCourses: mockCourses.filter((c) => c.teacherId === userId).length,
          totalStudents: mockCourses
            .filter((c) => c.teacherId === userId)
            .reduce((sum, c) => sum + (c.enrolledCount || 0), 0),
          averageRating:
            mockCourses
              .filter((c) => c.teacherId === userId && c.rating)
              .reduce((sum, c) => sum + (c.rating || 0), 0) /
            Math.max(
              mockCourses.filter((c) => c.teacherId === userId && c.rating).length,
              1
            ),
        };
        break;

      case 'parent':
        stats = {
          ...baseStats,
          // Parent-specific stats (viewing their children's data)
          childrenCount: 2,
          childrenActiveCourses: 3,
          childrenAverageGrade: 82,
          upcomingSessions: 4,
        };
        break;

      case 'admin':
      case 'owner':
        stats = {
          ...baseStats,
          // Admin/Owner get full stats
          pendingEnrollments: 12,
          monthlyRevenue: 420000,
          newStudentsThisMonth: 28,
          courseCompletionRate: 78,
        };
        break;

      default:
        stats = baseStats;
    }

    return NextResponse.json({
      success: true,
      stats,
      role,
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
