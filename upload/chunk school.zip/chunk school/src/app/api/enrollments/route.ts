import { NextRequest, NextResponse } from 'next/server';
import { mockEnrollments, mockCourses } from '@/lib/mock-data';
import type { Enrollment, EnrollmentStatus } from '@/lib/types';

// In-memory store for any newly created enrollments
const createdEnrollments: Enrollment[] = [];
let enrollmentCounter = 100;

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get('studentId');
    const courseId = searchParams.get('courseId');
    const status = searchParams.get('status');

    // Combine mock enrollments with any dynamically created ones
    let allEnrollments = [...mockEnrollments, ...createdEnrollments];

    // Filter by studentId if provided
    if (studentId) {
      allEnrollments = allEnrollments.filter((e) => e.studentId === studentId);
    }

    // Filter by courseId if provided
    if (courseId) {
      allEnrollments = allEnrollments.filter((e) => e.courseId === courseId);
    }

    // Filter by status if provided
    if (status) {
      allEnrollments = allEnrollments.filter((e) => e.status === status);
    }

    return NextResponse.json({
      success: true,
      enrollments: allEnrollments,
      total: allEnrollments.length,
    });
  } catch (error) {
    console.error('Enrollments GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { studentId, courseId } = body;

    // Validate required fields
    if (!studentId || !courseId) {
      return NextResponse.json(
        { error: 'studentId and courseId are required' },
        { status: 400 }
      );
    }

    // Check if the course exists
    const allCourses = [...mockCourses];
    const course = allCourses.find((c) => c.id === courseId);
    if (!course) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      );
    }

    // Check if already enrolled
    const allEnrollments = [...mockEnrollments, ...createdEnrollments];
    const existingEnrollment = allEnrollments.find(
      (e) => e.studentId === studentId && e.courseId === courseId && e.status !== 'rejected'
    );
    if (existingEnrollment) {
      return NextResponse.json(
        { error: 'Student is already enrolled in this course' },
        { status: 409 }
      );
    }

    enrollmentCounter++;
    const newEnrollment: Enrollment = {
      id: `e${enrollmentCounter}`,
      studentId,
      courseId,
      status: 'pending' as EnrollmentStatus,
      enrolledAt: new Date().toISOString().split('T')[0],
      progress: 0,
      course,
    };

    createdEnrollments.push(newEnrollment);

    return NextResponse.json(
      {
        success: true,
        enrollment: newEnrollment,
        message: 'Enrollment created successfully',
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Enrollments POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
