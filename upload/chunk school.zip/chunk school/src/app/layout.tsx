import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Champs School - تشامبس سكول | منصة تعليمية متقدمة",
  description:
    "منصة تعليمية متقدمة تجمع بين التكنولوجيا الحديثة وأساليب التعلم المبتكرة. An advanced educational platform combining modern technology and innovative learning methods. Plateforme éducative avancée combinant technologie moderne et méthodes d'apprentissage innovantes.",
  keywords: [
    "Champs School",
    "تشامبس سكول",
    "تعليم",
    "education",
    "الجزائر",
    "Algeria",
    "لغات",
    "languages",
    "دورات",
    "courses",
    "تعلم الكتروني",
    "e-learning",
  ],
  authors: [{ name: "Champs School" }],
  icons: {
    icon: "/champs-logo.png",
  },
  openGraph: {
    title: "Champs School - منصة تعليمية متقدمة",
    description:
      "منصة تعليمية متقدمة تجمع بين التكنولوجيا الحديثة وأساليب التعلم المبتكرة",
    type: "website",
    locale: "ar_DZ",
    alternateLocale: ["en_US", "fr_DZ"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" suppressHydrationWarning>
      <body
        className="bg-background font-sans text-foreground antialiased"
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
